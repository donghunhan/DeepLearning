#include <stdio.h>
int main()
{
	int x = 10;
	double y = 3.14;
	y = x * y;
	printf("%4.20f\n", y);
	return 0;
}
